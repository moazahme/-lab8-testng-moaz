package tests.exercise3;

// Name: Moaz Ahmed Helmy
// ID: 2022170939

import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

public class Exercise3GroupsTest {

    @BeforeGroups({"Smoke", "Regression"})
    public void beforeGroups() {
        System.out.println("Starting selected group...");
    }

    @AfterGroups({"Smoke", "Regression"})
    public void afterGroups() {
        System.out.println("Finished selected group.");
    }

    @Test(groups = {"Smoke"})
    public void testHomepageLoads() {
        Assert.assertTrue(true);
    }

    @Test(groups = {"Smoke"})
    public void testLoginPageVisible() {
        Assert.assertTrue(true);
    }

    @Test(groups = {"Smoke"})
    public void testFooterLinks() {
        Assert.assertTrue(true);
    }

    @Test(groups = {"Regression"})
    public void testLoginValidCreds() {
        Assert.assertTrue(true);
    }

    @Test(groups = {"Regression"})
    public void testLoginInvalidCreds() {
        Assert.assertTrue(true);
    }

    @Test(groups = {"Regression"})
    public void testPasswordReset() {
        Assert.assertTrue(true);
    }

    @Test(groups = {"Regression"})
    public void testAccountBalance() {
        Assert.assertTrue(true);
    }
}
