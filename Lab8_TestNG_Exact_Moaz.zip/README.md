# Lab 8 TestNG Assignment
Name: Moaz Ahmed Helmy
ID: 2022170939

## What matches the lab
- Exercise 1: lifecycle ordering with @BeforeTest, priorities, and @AfterTest
- Exercise 2: cross-browser + DataProvider login on https://demo.guru99.com/test/login.html
- Exercise 3: Smoke and Regression groups, plus @BeforeGroups and @AfterGroups
- Exercise 4: GitHub Actions workflow file, suite XML under src/test/resources, and pipeline support test classes

## Files to run
- src/test/resources/testng.xml
- src/test/resources/testng-cross-browser.xml
- src/test/resources/testng-regression-only.xml

## Manual items required by the lab
- Create GitHub repository and push the project
- Run the GitHub Actions pipeline
- Download the HTML report artifact
- Create the required Confluence pages and paste screenshots
