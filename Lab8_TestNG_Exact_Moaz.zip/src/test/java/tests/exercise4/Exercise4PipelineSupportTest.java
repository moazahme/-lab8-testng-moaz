package tests.exercise4;

// Name: Moaz Ahmed Helmy
// ID: 2022170939

import org.testng.Assert;
import org.testng.annotations.Test;

public class Exercise4PipelineSupportTest {

    @Test
    public void testSuiteIsReadyForPipeline() {
        Assert.assertTrue(true);
    }

    @Test
    public void testReportsCanBeGenerated() {
        Assert.assertTrue(true);
    }
}
