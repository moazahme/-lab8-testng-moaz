package tests.exercise1;

// Name: Moaz Ahmed Helmy
// ID: 2022170939

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class Exercise1LifecycleTest {

    private final List<String> executionOrder = new ArrayList<>();

    @BeforeTest
    public void openWebSite() {
        executionOrder.add("openWebSite");
        System.out.println("Opening homepage...");
    }

    @Test(priority = 1)
    public void signUp() {
        executionOrder.add("signUp");
        System.out.println("Signing up...");
        Assert.assertTrue(true);
    }

    @Test(priority = 2)
    public void logIn() {
        executionOrder.add("logIn");
        System.out.println("Logging in...");
        Assert.assertTrue(true);
    }

    @Test(priority = 3)
    public void addToCart() {
        executionOrder.add("addToCart");
        System.out.println("Adding product to cart...");
        Assert.assertTrue(true);
    }

    @AfterTest
    public void logOut() {
        executionOrder.add("logOut");
        System.out.println("Logging out...");
        Assert.assertEquals(
                executionOrder,
                List.of("openWebSite", "signUp", "logIn", "addToCart", "logOut")
        );
    }
}
