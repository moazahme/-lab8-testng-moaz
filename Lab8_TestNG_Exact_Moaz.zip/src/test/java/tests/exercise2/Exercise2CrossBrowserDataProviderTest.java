package tests.exercise2;

// Name: Moaz Ahmed Helmy
// ID: 2022170939

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class Exercise2CrossBrowserDataProviderTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @Parameters("browser")
    @BeforeClass
    public void setUp(String browser) {
        if (browser.equalsIgnoreCase("firefox")) {
            driver = new FirefoxDriver();
        } else {
            driver = new ChromeDriver();
        }

        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        return new Object[][]{
                {"test@mail.com", "123", false},
                {"test@mail.com", "152", true}
        };
    }

    @Test(dataProvider = "loginData")
    public void loginTest(String user, String pwd, boolean validLogin) {
        driver.get("https://demo.guru99.com/test/login.html");

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email"))).clear();
        driver.findElement(By.id("email")).sendKeys(user);

        driver.findElement(By.id("passwd")).clear();
        driver.findElement(By.id("passwd")).sendKeys(pwd);

        driver.findElement(By.id("SubmitLogin")).click();

        if (validLogin) {
            wait.until(ExpectedConditions.urlContains("success"));
            Assert.assertTrue(driver.getCurrentUrl().contains("success"));
        } else {
            String errorMessage = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(By.id("message"))
            ).getText();
            Assert.assertTrue(errorMessage.toLowerCase().contains("invalid"));
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
